def despedir():
    print('me estoy despidiendo, funcion despedir')

class despedida():
    def __init__(self):
        print('me estoy despidiendo desde el __init__')
