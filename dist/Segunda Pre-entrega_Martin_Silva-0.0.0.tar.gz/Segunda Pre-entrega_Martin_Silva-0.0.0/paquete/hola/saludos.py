def saludar():
    print('hola estoy desde la funcion saludar')

class saludo():
    def __init__(self):
        print('hola estoy desde  __init__')
        