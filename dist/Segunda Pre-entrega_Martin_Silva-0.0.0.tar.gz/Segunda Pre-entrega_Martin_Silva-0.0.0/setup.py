from setuptools import setup

setup(
    name='Segunda Pre-entrega_Martin_Silva',
    description='Atributos, Metodos y Distribucion',
    author='Martin Silva',
    author_email='martins80@hotmail.es',

    packages=['paquete', 'paquete.hola', 'paquete.adios'],
    scripts=[]

)